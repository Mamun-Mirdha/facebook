<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook</title>

    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <!-- header area start here -->
    <header class="header-area sticky-top">
       <div class="row">
        <div class="col-md-4">
            <div class="header-lodo-area">
              <div class="row">
                <div class="col-md-2 g-0">
                    <div class="header-logo">
                        <img src="./img/logo.png" alt="">
                    </div>
                </div>
                <div class="col-md-10 g-0">
                    <div class="header-search">
                        <input type="search" placeholder="Search Facebook" name="" id="">
                    </div>
                </div>
              </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="header-icon-area">
                <ul>
                    <li><a title="Home" href="#" class="active"><i class="fa-solid fa-house"></i></a></li>
                    <li><a title="Watch" href="#"><i class="fa-solid fa-tv"></i></a></li>
                    <li><a title="Marketplace" href="#"><i class="fa-solid fa-store"></i></a></li>
                    <li><a title="Group" href="#"><i class="fa-solid fa-circle-user"></i></a></li>
                    <li><a title="Gamming" href="#"><i class="fa-solid fa-dice-d20"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-2">
            <div class="icon-area-right">
                <ul>
                  
                    
                    <li id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false"><a title="Menu" href="#"><i class="fa-solid fa-bars"></i></a></li>
                    <ul class="dropdown-menu dropdown-menu-dark akta-class total-images" aria-labelledby="dropdownMenuButton2">
                        <li>
                            <a class="dropdown-item" href="#">
                                <i class="fa-solid fa-right-from-bracket"></i>
                                <span>Log Out</span>
                            </a>
                        </li>
                    </ul>
                    <li><a title="Message" href="#"><i class="fa-solid fa-message"></i></a></li>
                    <li><a title="Notification" href="#"><i class="fa-solid fa-bell"></i></a></li>
                    <div class="profile-images">
                        <li><a title="Your Profile" href="#"><img src="./img/mamun.jpg" alt=""></a></li>
                    </div>
                </ul>

            </div>
        </div>
       </div>
    </header>
    <!-- header area end here -->
    <!-- ==============================
    |  	Body  AREA START HERE     |
    =============================== -->
    
    <section class="facebook-full-body">
        <div class="facebook-body clearfix ">
            <div class="facebook-left-side float-start">
                <aside class="left-side total-images">
                    <ul>
                        <li>
                            <a href="#">
                                <img src="img/mamun.jpg" alt="">
                                <span>Mamun Mirdha</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-1.png" alt="">
                                <span>Friends</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-2.png" alt="">
                                <span>Watch</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-3.png" alt="">
                                <span>Groups</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-4.png" alt="">
                                <span>Marketplace</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-5.png" alt="">
                                <span>Memories</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/left-side-6.png" alt="">
                                <span>Saved</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-angle-down"></i>
                                <span>See More</span>
                            </a>
                        </li>
                    </ul>
                    <hr>
                    <div class="shortcuts">
                        <h3>
                            <span>Your shortcuts</span>
                            <a href="#">Edit</a>

                        </h3>
                    </div>
                    <ul>
                        <li>
                            <a href="#">
                                <img src="./img/sidebar-bottom-1.jpg" alt="">
                                <span>Fiverr Help & Support Bangladesh</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="./img/bottom-2.png" alt="">
                                <span>Learn Freelancing With Fun (SoroBindu)</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="./img/bottom-3.jpg" alt="">
                                <span>💔অসমাপ্ত ভালোবাসা💔</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="img/mamun.jpg" alt="">
                                <span>Mamun Mirdha</span>
                            </a>
                        </li>
                        <p>Privacy  · Terms  · Advertising  · Ad choices   · Cookies  ·   · Meta © 2022</p>
                    </ul>
                </aside>
            </div>
            <div class="facebook-meddle-side float-start m-auto">
                <div class="facebook-meddle-content ">
                        <div class="storiy-area clearfix">
                            <div class="main-profile friens-story w-20 float-start">
                                <div class="main-content text-center">
                                    <a href="#">
                                        <img src="./img/mamun.jpg" alt="">
                                        <div class="pic-info">
                                            <span><i class="fa-solid fa-circle-plus"></i></span>
                                            <p>Creact story</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="friens-story w-20 float-start">
                                <div class="f-content">
                                    <div class="pro-pic">
                                        <a href="#"><img src="./img/JIBON-RAHMAN.jpg" alt=""></a>
                                    </div>
                                    <div class="pro-banner">
                                        <a href="#">
                                            <img src="./img/11.jpg" alt="">
                                            <p>JIBON RAHMAN</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="friens-story w-20 float-start">
                                <div class="f-content">
                                    <div class="pro-pic">
                                        <a href="#"><img src="./img/teem-4.jpg" alt=""></a>
                                    </div>
                                    <div class="pro-banner">
                                        <a href="#">
                                            <img src="./img/teem-4.jpg" alt="">
                                            <p>JIBON RAHMAN</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="friens-story w-20 float-start">
                                <div class="f-content">
                                    <div class="pro-pic">
                                        <a href="#"><img src="./img/JIBON-RAHMAN.jpg" alt=""></a>
                                    </div>
                                    <div class="pro-banner">
                                        <a href="#">
                                            <img src="./img/JR-IMG.jpg" alt="">
                                            <p>JIBON RAHMAN</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="friens-story w-20 float-start">
                                <div class="f-content">
                                    <div class="pro-pic">
                                        <a href="#"><img src="./img/JIBON-RAHMAN.jpg" alt=""></a>
                                    </div>
                                    <div class="pro-banner">
                                        <a href="#">
                                            <img src="./img/JR-IMG.jpg" alt="">
                                            <p>JIBON RAHMAN</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="user-post-area">
                            <div class="user-all-post">
                                <div class="post-input">
                                    <form action="">
                                        <img src="./img/mamun.jpg" alt="">
                                        <textarea name="" placeholder="What's your mind , Mamun?"></textarea>
                                    </form>
                                </div>
                                <hr>
                                
                                <div class="socail-video-upload total-images">
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <img src="img/s1.png" alt="">
                                                <span>Live video</span>
                                            </a>
                                            <a href="#">
                                                <img src="img/s2.png" alt="">
                                                <span>Photo/video</span>
                                            </a>
                                            <a href="#">
                                                <img src="img/s3.png" alt="">
                                                <span>Feeling/Activity</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="active-friends">
                                <div class="all-active-friens">
                                   
                                    <div class="user-pic total-images">
                                        <ul>
                                            <li class="creact-room">
                                                <a href="#">
                                                    <img src="img/Screenshot_1.png" alt="">
                                                    <span>Creact Room</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="user-upload-post">
                                <div class="user-upload-future-post">
                                    <div class="upload-post-detels">
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                    <span>Mamun Mirdha</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="post-edit"><i class="fa-solid fa-ellipsis"></i></span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="post-content-images">
                                            <div class="post-content-file">
                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo et totam aliquid exercitationem ipsum amet excepturi culpa odit ut harum sapiente iste voluptatum suscipit, repudiandae mollitia accusantium laudantium vitae quod!</p>
                                            </div>
                                            <div class="post-imagesss">
                                                <img src="./img/mamun.jpg" alt="">
                                            </div>
                                            <div class="post-comment">
                                                <hr>
                                                <div class="socail-video-upload total-images">
                                                    <ul>
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa-solid fa-thumbs-up"></i>
                                                                <span>Like</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-message"></i>
                                                                <span>Comment</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-share"></i>
                                                                <span>Share</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <hr>

                                                <div class="user-conmment">
                                                    <div class="post-input">
                                                        <form action="">
                                                            <img src="./img/mamun.jpg" alt="">
                                                            <textarea name="" placeholder="Write a comment...."></textarea>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            

                            <div class="user-upload-post">
                                <div class="user-upload-future-post">
                                    <div class="upload-post-detels">
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                    <span>Mamun Mirdha</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="post-edit"><i class="fa-solid fa-ellipsis"></i></span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="post-content-images">
                                            <div class="post-content-file">
                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo et totam aliquid exercitationem ipsum amet excepturi culpa odit ut harum sapiente iste voluptatum suscipit, repudiandae mollitia accusantium laudantium vitae quod!</p>
                                            </div>
                                            <div class="post-imagesss">
                                                <img src="./img/mamun.jpg" alt="">
                                            </div>
                                            <div class="post-comment">
                                                <hr>
                                                <div class="socail-video-upload total-images">
                                                    <ul>
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa-solid fa-thumbs-up"></i>
                                                                <span>Like</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-message"></i>
                                                                <span>Comment</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-share"></i>
                                                                <span>Share</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <hr>

                                                <div class="user-conmment">
                                                    <div class="post-input">
                                                        <form action="">
                                                            <img src="./img/mamun.jpg" alt="">
                                                            <textarea name="" placeholder="Write a comment...."></textarea>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="user-upload-post">
                                <div class="user-upload-future-post">
                                    <div class="upload-post-detels">
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <img src="./img/mamun.jpg" alt="">
                                                    <span>Mamun Mirdha</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="post-edit"><i class="fa-solid fa-ellipsis"></i></span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="post-content-images">
                                            <div class="post-content-file">
                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo et totam aliquid exercitationem ipsum amet excepturi culpa odit ut harum sapiente iste voluptatum suscipit, repudiandae mollitia accusantium laudantium vitae quod!</p>
                                            </div>
                                            <div class="post-imagesss">
                                                <img src="./img/mamun.jpg" alt="">
                                            </div>
                                            <div class="post-comment">
                                                <hr>
                                                <div class="socail-video-upload total-images">
                                                    <ul>
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa-solid fa-thumbs-up"></i>
                                                                <span>Like</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-message"></i>
                                                                <span>Comment</span>
                                                            </a>
                                                            <a href="#">
                                                                <i class="fa-solid fa-share"></i>
                                                                <span>Share</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <hr>

                                                <div class="user-conmment">
                                                    <div class="post-input">
                                                        <form action="">
                                                            <img src="./img/mamun.jpg" alt="">
                                                            <textarea name="" placeholder="Write a comment...."></textarea>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>

                </div>
            </div>
            <div class="facebook-right-side float-start">
                <div class="right-side">
                    <div class="shortcuts right-header">
                        <h3>
                            <span class="">Sponsored</span>
                        </h3>
                    </div>
                   <div class="edd-top-banner total-images">
                        <ul>
                            <li>
                                <a href="#">
                                    <img src="img/add-1.jpg" alt="">
                                    <span>PC Gaming Benchmarks</span><br>
                                    <span>Youtube.com</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/banner-2.png" alt="">
                                    <span>Don't wait, act now!</span><br>
                                    <span>whitebit.com</span>
                                </a>
                            </li>
                        </ul>
                   </div>
                   <hr>
                   <div class="shortcuts">
                        <h3>
                            <span>Your Pages and profiles</span>
                            <a href="#"><i class="fa-solid fa-ellipsis"></i></a>
                        </h3>
                    </div>
                    <div class="page-file total-images">
                        <ul>
                            <li>
                                <a href="#">
                                    <img src="img/mamun.jpg" alt="">
                                    <span>Mamun Mirdha</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span><i class="fa-solid fa-bell"></i></span>
                                    <span>8 Notifications</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span><i class="fa-solid fa-bullhorn"></i></span>
                                    <span>Create Promotion</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <hr>


                    <div class="shortcuts Contacts">
                        <h3>
                            <span>Contacts</span>
                            <a href="#"><i class="fa-solid fa-video"></i></a>
                            <a href="#"><i class="fa-solid fa-magnifying-glass"></i></a>
                            <a href="#"><i class="fa-solid fa-ellipsis"></i></a>

                        </h3>
                    </div>
                    <hr>

                    <div class="about-all-friend total-images">
                        <ul>
                            <li>
                                <a href="#">
                                    <img src="img/1.jpg" alt="">
                                    <span>Dazzling Diya</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/289337038_1239683230174245_6912182427194153523_n.jpg" alt="">
                                    <span>Rabbani Islam</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/1.jpg" alt="">
                                    <span>Dazzling Diya</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/289337038_1239683230174245_6912182427194153523_n.jpg" alt="">
                                    <span>Rabbani Islam</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/1.jpg" alt="">
                                    <span>Dazzling Diya</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/289337038_1239683230174245_6912182427194153523_n.jpg" alt="">
                                    <span>Rabbani Islam</span>
                                </a>
                            </li>
                             <li>
                                <a href="#">
                                    <img src="img/1.jpg" alt="">
                                    <span>Dazzling Diya</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/289337038_1239683230174245_6912182427194153523_n.jpg" alt="">
                                    <span>Rabbani Islam</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/1.jpg" alt="">
                                    <span>Dazzling Diya</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/289337038_1239683230174245_6912182427194153523_n.jpg" alt="">
                                    <span>Rabbani Islam</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <hr>

                    <div class="shortcuts Contacts">
                        <h3>
                            <span>Group conversations</span>
                        </h3>
                    </div>

                    <div class="group-cccc total-images">
                        <ul>
                            <li>
                                <a href="#">
                                    <i class="fa-solid fa-angle-down"></i>
                                    <span>Create New Group</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>




















    <!-- ==============================
    |  	body  AREA END HERE     |
    =============================== -->



    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>



    
</body>
</html>